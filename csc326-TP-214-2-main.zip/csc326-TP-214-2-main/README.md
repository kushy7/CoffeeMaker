# CoffeeMaker

To run CoffeeMaker for the first time, ensure that the 'src/main/resources/application.yml' and 'src/resources/application.properties' files have been copied from their .tmp counterparts (and appropriately filled out with database credentials/a staff signup key).


*Line Coverage (should be >=70%)*

![Coverage](.github/badges/jacoco.svg)

*Branch Coverage (should be >=50%)*

![Branches](.github/badges/branches.svg)
