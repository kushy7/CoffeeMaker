package edu.ncsu.csc.CoffeeMaker.models;

/** Enumerates types of users */
public enum UserType {
    CUSTOMER, STAFF;
}