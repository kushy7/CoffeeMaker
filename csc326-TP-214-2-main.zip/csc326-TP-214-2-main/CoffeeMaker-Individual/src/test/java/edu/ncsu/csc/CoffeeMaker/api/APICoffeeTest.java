package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

@ExtendWith ( SpringExtension.class )
@SpringBootTest
@AutoConfigureMockMvc
public class APICoffeeTest {

    @Autowired
    private MockMvc          mvc;

    @Autowired
    private RecipeService    service;

    @Autowired
    private InventoryService iService;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
        iService.deleteAll();

        final Inventory ivt = iService.getInventory();
        
        ivt.setIngredient( new Ingredient("chocolate", 15) );
        ivt.setIngredient( new Ingredient("coffee", 15) );
        ivt.setIngredient( new Ingredient("milk", 15) );
        ivt.setIngredient( new Ingredient("sugar", 15) );

        iService.save( ivt );

        final Recipe recipe = new Recipe();
        recipe.setName( "Coffee" );
        recipe.setPrice( 50 );
        recipe.addIngredient( new Ingredient("coffee", 3) );
        recipe.addIngredient( new Ingredient("milk", 1) );
        recipe.addIngredient( new Ingredient("sugar", 1) );
        service.save( recipe );
    }

    @Test
    @Transactional
    public void testPurchaseBeverage1 () throws Exception {

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name ) ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 60 ) ) ).andExpect( status().isOk() )
                .andExpect( jsonPath( "$.message" ).value( 10 ) );

    }

    @Test
    @Transactional
    public void testPurchaseBeverage2 () throws Exception {
        /* Insufficient amount paid */

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name ) ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 40 ) ) ).andExpect( status().is4xxClientError() )
                .andExpect( jsonPath( "$.message" ).value( "Not enough money paid" ) );

    }

    // @Test
    // @Transactional
    // public void testPurchaseBeverage3 () throws Exception {
    // /* Insufficient inventory */
    //
    // final Inventory ivt = iService.getInventory();
    // ivt.setCoffee( 0 );
    // iService.save( ivt );
    //
    // final String name = "Coffee";
    //
    // mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name )
    // ).contentType( MediaType.APPLICATION_JSON )
    // .content( TestUtils.asJsonString( 50 ) ) ).andExpect(
    // status().is4xxClientError() )
    // .andExpect( jsonPath( "$.message" ).value( "Not enough inventory" ) );
    //
    // }

    // test for the index method in MappingController class
    @Test
    @Transactional
    public void testIndex () throws Exception {
        mvc.perform( get( "/index" ) ).andExpect( status().isOk() ).andExpect( view().name( "index" ) );
    }
    
    /*
    // test for the addRecipePage method in MappingController class
    @Test
    @Transactional
    public void testAddRecipePage () throws Exception {
        mvc.perform( get( "/recipe" ) ).andExpect( status().isOk() ).andExpect( view().name( "recipe" ) );
    }
    */
    
    /*
    // test for the deleteRecipeFrom method in MappingController class
    @Test
    @Transactional
    public void testDeleteRecipeForm () throws Exception {
        mvc.perform( get( "/deleterecipe" ) ).andExpect( status().isOk() ).andExpect( view().name( "deleterecipe" ) );
    }
    
    /*

    // edit recipe not working correctly yet
    // @Test
    // @Transactional
    // public void testEditRecipeForm () throws Exception {
    // mvc.perform( get( "/editrecipe" ) ).andExpect( status().isOk()
    // ).andExpect( view().name( "editrecipe" ) );
    // }

    /*
    // test for the inventoryFrom method in MappingController class
    @Test
    @Transactional
    public void testInventoryForm () throws Exception {
        mvc.perform( get( "/inventory" ) ).andExpect( status().isOk() ).andExpect( view().name( "inventory" ) );
    }
    */
    
    /*
    // test for the makeCoffeeFrom method in MappingController class
    @Test
    @Transactional
    public void testMakeCoffeeForm () throws Exception {
        mvc.perform( get( "/makecoffee" ) ).andExpect( status().isOk() ).andExpect( view().name( "makecoffee" ) );
    }
    */
}
